<?php if ( is_active_sidebar( 'sidebar' ) ){ ?>
	<div id="sidebar">
		<?php dynamic_sidebar( 'sidebar' ); ?>
	</div> <!-- end #sidebar -->
<?php } ?>